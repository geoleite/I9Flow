package br.com.i9.flow.transfer;

import br.com.easynet.annotation.Conversion;

public class Are_areaT { 
	 private int are_nr_id;
	 private String are_tx_nome;
	 public void setAre_nr_id(int are_nr_id) {
		 this.are_nr_id=are_nr_id;
	}
 
	 public int getAre_nr_id() {
		 return are_nr_id;
 	} 
 	 public void setAre_tx_nome(String are_tx_nome) {
		 this.are_tx_nome=are_tx_nome;
	}
 
	 public String getAre_tx_nome() {
		 return are_tx_nome;
 	} 
 }