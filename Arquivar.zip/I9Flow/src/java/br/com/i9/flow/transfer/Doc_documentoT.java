package br.com.i9.flow.transfer;

import br.com.easynet.annotation.Conversion;

public class Doc_documentoT { 
	 private int doc_nr_id;
	 private int flx_nr_id;
	 public void setDoc_nr_id(int doc_nr_id) {
		 this.doc_nr_id=doc_nr_id;
	}
 
	 public int getDoc_nr_id() {
		 return doc_nr_id;
 	} 
 	 public void setFlx_nr_id(int flx_nr_id) {
		 this.flx_nr_id=flx_nr_id;
	}
 
	 public int getFlx_nr_id() {
		 return flx_nr_id;
 	} 
 }