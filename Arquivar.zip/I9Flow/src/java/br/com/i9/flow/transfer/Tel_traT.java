package br.com.i9.flow.transfer;

import br.com.easynet.annotation.Conversion;

public class Tel_traT { 
	 private int tra_nr_id;
	 private int tel_nr_id;
	 public void setTra_nr_id(int tra_nr_id) {
		 this.tra_nr_id=tra_nr_id;
	}
 
	 public int getTra_nr_id() {
		 return tra_nr_id;
 	} 
 	 public void setTel_nr_id(int tel_nr_id) {
		 this.tel_nr_id=tel_nr_id;
	}
 
	 public int getTel_nr_id() {
		 return tel_nr_id;
 	} 
 }