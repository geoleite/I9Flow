package br.com.i9.flow.transfer;

import br.com.easynet.annotation.Conversion;

public class Aru_usu_areaT { 
	 private int usu_nr_id;
	 private int are_nr_id;
	 public void setUsu_nr_id(int usu_nr_id) {
		 this.usu_nr_id=usu_nr_id;
	}
 
	 public int getUsu_nr_id() {
		 return usu_nr_id;
 	} 
 	 public void setAre_nr_id(int are_nr_id) {
		 this.are_nr_id=are_nr_id;
	}
 
	 public int getAre_nr_id() {
		 return are_nr_id;
 	} 
 }