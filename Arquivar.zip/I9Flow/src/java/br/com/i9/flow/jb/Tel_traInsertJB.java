package br.com.i9.flow.jb;

import java.util.List;
import br.com.easynet.jb.BeanBase;
import br.com.jdragon.dao.DAOFactory;
import br.com.i9.flow.bl.*;
import br.com.i9.flow.dao.*;
import br.com.i9.flow.transfer.*;



/** Classe Criada Automaticamente pelo "EasyNet Generate JDragon" */

public class Tel_traInsertJB extends SystemBase {
  private Tel_traBL tel_traBL = new Tel_traBL();
  // Atributos e propriedades
  private Tel_traT tel_traT = new Tel_traT();

  public void setTel_traT(Tel_traT tel_traT) {
    this.tel_traT = tel_traT;
  }

  public Tel_traT getTel_traT() {	
    return tel_traT;
  }

	
  public void pageLoad() throws Exception {
    super.pageLoad();
  }

  // Metodos de Eventos
  public void insert() throws Exception {
    try {
      tel_traBL.insert(tel_traT);
      setMsg(INFO,"Cadastro efetuado com sucesso!");
    } catch (Exception e) {
      setMsg(ERROR,"Falha: ".concat(e.getMessage()) );	
    } finally {
      close();
    }
  } 
}
