/*
 * Define constantes para acesso aos jsp do servidor
 */

package br.com.i9.flow.client;

/**
 *
 * @author geoleite
 */
public class Constantes {
    public static String URL = "/i9flow/";
}

