/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.i9.flow.client.icons;

import com.google.gwt.core.client.GWT;

/**
 *
 * @author geoleite
 */
public class Icons {
    public final static IconsFluxo ICONS = GWT.create(IconsFluxo.class);
}
